# PHP-CS-Fixer/diff

This version is for PHP CS Fixer only! Do not use it!

Code from `sebastian/diff` has been forked a republished by permission of Sebastian Bergmann.
Main change is to make the package compatible with older PHP engines.
Licenced with BSD-3-Clause @ see LICENSE, copyright (c) Sebastian Bergmann <sebastian@phpunit.de>
https://github.com/sebastianbergmann/diff

For questions visit us @ https://gitter.im/PHP-CS-Fixer/Lobby
