<?php

declare (strict_types=1);
namespace Rector\StaticTypeMapper\ValueObject\Type;

use PHPStan\Type\ThisType;
final class SelfStaticType extends \PHPStan\Type\ThisType
{
}
